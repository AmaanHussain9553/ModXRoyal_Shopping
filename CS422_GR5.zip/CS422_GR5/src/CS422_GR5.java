import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class CS422_GR5 extends JFrame {

    // These are the private variables accessible by all functions
    //
    private static JFrame f = new JFrame("Welcome Screen");
    private static JLabel t1 = new JLabel("Modx Royal");
    private static Font headingFont = new Font("Times New Roman", Font.BOLD + Font.ITALIC, 30);
    private static Font inputFont = new Font("Calibri", Font.BOLD, 16);
    private static Font smallFont = new Font("Calibri", Font.BOLD, 10);
    private static JTextField i3 = new JTextField("Search");
    private static final JPopupMenu menu = new JPopupMenu();
    private static JMenuItem item9 = new JMenuItem("Home");
    private static JMenuItem item1 = new JMenuItem("Categories");
    private static JMenuItem item2 = new JMenuItem("Account");
    private static JMenuItem item3 = new JMenuItem("About");
    private static JMenuItem item4 = new JMenuItem("Terms and Conditions");
    private static JMenuItem item5 = new JMenuItem("Policies");
    private static JMenuItem item6 = new JMenuItem("FAQ");
    private static JMenuItem item7 = new JMenuItem("Seller Verification");
    private static JMenuItem item8 = new JMenuItem("Help");
    private static boolean initialized_menu = false;
    private static String seller1 = "David Houston \nAntique Collector, Car Enthusiast";
    private static String seller2 = "Lewis Hamilton \nFormula 1 Racer, Art Collector";
    private static String seller3 = "William Kopec \nResearch Scientist, Adventurous";
    private static String seller4 = "Chris Duarte \nFinancial Investor, Tech Enthusiast";
    private static int sellerID = 0;

    public static void defaultScreen() {
        f.setContentPane(new JLabel(new ImageIcon("resources/background.jpg")));
        f.setSize(350, 650);

        t1.setForeground(Color.RED);
        t1.setFont(headingFont);
        t1.setBounds(30, 10, 250, 30);

        //Account button
        JButton accbutton = new JButton(new ImageIcon(((new ImageIcon(
                "resources/img.png").getImage()
                .getScaledInstance(30, 30,
                        Image.SCALE_SMOOTH)))));
        accbutton.setBounds(280, 50, 30, 30);
        accbutton.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    AccountScreen();
                }
            }
        });

        //Cart button
        JButton cartbutton = new JButton(new ImageIcon(((new ImageIcon(
                "resources/img_1.png").getImage()
                .getScaledInstance(30, 30,
                        Image.SCALE_SMOOTH)))));
        cartbutton.setBounds(230, 50, 30, 30);

        //Menu button
        JButton menubutton = new JButton(new ImageIcon(((new ImageIcon(
                "resources/img_2.png").getImage()
                .getScaledInstance(60, 40,
                        Image.SCALE_SMOOTH)))));
        menubutton.setBounds(15, 90, 60, 40);

        i3.setBackground(Color.WHITE);
        i3.setForeground(new Color(0, 0, 0));
        i3.setFont(inputFont);
        i3.setBounds(20, 50, 200, 30);
        i3.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                i3.setText("Search: ");
            }

            @Override
            public void focusLost(FocusEvent e) {

            }
        });

        JMenuItem item1 = new JMenuItem("Categories");
        JMenuItem item2 = new JMenuItem("Account");
        JMenuItem item3 = new JMenuItem("About");
        JMenuItem item4 = new JMenuItem("Terms and Conditions");
        JMenuItem item5 = new JMenuItem("Policies");
        JMenuItem item6 = new JMenuItem("FAQ");
        JMenuItem item7 = new JMenuItem("Seller Verification");
        JMenuItem item8 = new JMenuItem("Help");
        item1.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    CategoryScreen();

                }
            }
        });

        item2.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    AccountScreen();

                }
            }
        });

        item3.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    AboutScreen();
                }
            }
        });

        item4.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    TermsConditions();
                }
            }
        });

        item5.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    PoliciesScreen();
                }
            }
        });

        item6.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    FAQScreen();
                }
            }
        });

        item7.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    SellerVerification();
                }
            }
        });

        item8.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    Help();
                }
            }
        });

        item9.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    try {
                        WelcomeScreen();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });

        if (!initialized_menu) {
            menu.add(item9);
            menu.add(item1);
            menu.add(item2);
            menu.add(item3);
            menu.add(item4);
            menu.add(item5);
            menu.add(item6);
            menu.add(item7);
            menu.add(item8);
            initialized_menu = true;
        }

        menubutton.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    menu.show(e.getComponent(), e.getX(), e.getY());
                }
            }
        });

        f.add(t1);
        f.add(accbutton);
        f.add(cartbutton);
        f.add(menubutton);
        f.add(i3);
        f.add(menu);

    }


    public static void WelcomeScreen() throws IOException {
        f.setVisible(false);
        defaultScreen();

        JButton recommend1 = new JButton();
        recommend1.setIcon(new ImageIcon(((new ImageIcon(
                "resources/planet1.jpg").getImage()
                .getScaledInstance(100, 100,
                        java.awt.Image.SCALE_SMOOTH)))));
        recommend1.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    sellerID = 1;
                    ProductDetails("resources/planet1.jpg", "Antique Globe", seller1, 550.5);
                }
            }
        });

        JButton recommend2 = new JButton();
        recommend2.setIcon(new ImageIcon(((new ImageIcon(
                "resources/clock1.jpg").getImage()
                .getScaledInstance(100, 100,
                        java.awt.Image.SCALE_SMOOTH)))));
        recommend2.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    sellerID = 2;
                    ProductDetails("resources/clock1.jpg", "Antique Clock", seller2, 395.5);
                }
            }
        });

        JButton recommend3 = new JButton();
        recommend3.setIcon(new ImageIcon(((new ImageIcon(
                "resources/sculpture.jpg").getImage()
                .getScaledInstance(100, 100,
                        java.awt.Image.SCALE_SMOOTH)))));
        recommend3.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    sellerID = 3;
                    ProductDetails("resources/sculpture.jpg", "Roman Sculpture", seller3, 780.3);
                }
            }
        });

        JButton recommend4 = new JButton();
        recommend4.setIcon(new ImageIcon(((new ImageIcon(
                "resources/bike1.jpg").getImage()
                .getScaledInstance(100, 100,
                        java.awt.Image.SCALE_SMOOTH)))));
        recommend4.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    sellerID = 4;
                    ProductDetails("resources/bike1.jpg", "Relaxing Bike", seller4, 170.8);
                }
            }
        });

        JButton popular1 = new JButton();
        popular1.setIcon(new ImageIcon(((new ImageIcon(
                "resources/car1.jpg").getImage()
                .getScaledInstance(100, 100,
                        java.awt.Image.SCALE_SMOOTH)))));
        popular1.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    sellerID = 1;
                    ProductDetails("resources/car1.jpg", "Car 1", seller1, 89550.5);
                }
            }
        });

        JButton popular2 = new JButton();
        popular2.setIcon(new ImageIcon(((new ImageIcon(
                "resources/car2.jpg").getImage()
                .getScaledInstance(100, 100,
                        java.awt.Image.SCALE_SMOOTH)))));
        popular2.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    sellerID = 2;
                    ProductDetails("resources/car2.jpg", "Car 2", seller2, 10550.5);
                }
            }
        });

        JButton popular3 = new JButton();
        popular3.setIcon(new ImageIcon(((new ImageIcon(
                "resources/car3.jpg").getImage()
                .getScaledInstance(100, 100,
                        java.awt.Image.SCALE_SMOOTH)))));
        popular3.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    sellerID = 3;
                    ProductDetails("resources/car3.jpg", "Car 2", seller3, 35550.5);
                }
            }
        });

        JButton popular4 = new JButton();
        popular4.setIcon(new ImageIcon(((new ImageIcon(
                "resources/car4.jpg").getImage()
                .getScaledInstance(100, 100,
                        java.awt.Image.SCALE_SMOOTH)))));
        popular4.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    sellerID = 3;
                    ProductDetails("resources/car4.jpg", "Car 2", seller3, 35550.5);
                }
            }
        });

        // Label with ModX Royal Title
        JLabel t2 = new JLabel("Popular Items");
        t2.setForeground(Color.BLUE);
        t2.setFont(headingFont);
        t2.setBounds(100, 90, 250, 30);

        JPanel recommended = new JPanel(new GridLayout(2, 2));
        recommended.add(recommend1);
        recommended.add(recommend2);
        recommended.add(recommend3);
        recommended.add(recommend4);
        recommended.setBounds(100, 120, 210, 210);

        JLabel t3 = new JLabel("Recommended Items");
        t3.setForeground(Color.BLUE);
        t3.setFont(headingFont);
        t3.setBounds(40, 340, 300, 30);

        JPanel popular = new JPanel(new GridLayout(2, 2));
        popular.add(popular1);
        popular.add(popular2);
        popular.add(popular3);
        popular.add(popular4);
        popular.setBounds(70, 380, 210, 210);

        f.add(recommended);
        f.add(t2);
        f.add(t3);
        f.add(popular);
        f.setLayout(null);
        f.setVisible(true);
    }

    public static void CategoryScreen() {
        f.setVisible(false);
        defaultScreen();

        f.setLayout(null);
        f.setVisible(true);

    }

    public static void AccountScreen() {
        f.setVisible(false);
        defaultScreen();

        JButton payment = new JButton("Add Payment Info");
        payment.setBackground(Color.BLUE);
        payment.setForeground(Color.WHITE);
        payment.setFont(inputFont);
        payment.setBounds(30, 150, 180, 40);
        payment.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    Payment();
                }
            }
        });


        JButton shipping = new JButton("Add Shipping Info");
        shipping.setBackground(Color.BLUE);
        shipping.setForeground(Color.WHITE);
        shipping.setFont(inputFont);
        shipping.setBounds(30, 220, 180, 40);
        shipping.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    Shipping();
                }
            }
        });

        JButton account = new JButton("Modify Account Info");
        account.setBackground(Color.BLUE);
        account.setForeground(Color.WHITE);
        account.setFont(inputFont);
        account.setBounds(30, 290, 180, 40);
        account.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    ModifyAcc();
                }
            }
        });

        JTextArea safetyTransaction = new JTextArea();
        safetyTransaction.setText("Safety Transaction Info here.....");
        safetyTransaction.setFont(inputFont);
        safetyTransaction.setBackground(Color.YELLOW);
        safetyTransaction.setForeground(Color.BLACK);
        safetyTransaction.setBorder(BorderFactory.createMatteBorder(
                1, 5, 1, 1, Color.red));
        safetyTransaction.setOpaque(true);
        safetyTransaction.setBounds(30, 380, 250, 150);


        f.add(payment);
        f.add(shipping);
        f.add(account);
        f.add(safetyTransaction);
        f.setLayout(null);
        f.setVisible(true);

    }

    public static void Payment() {
        f.setVisible(false);
        defaultScreen();

        JLabel t2 = new JLabel("Payment Info");
        t2.setForeground(Color.BLUE);
        t2.setFont(headingFont);
        t2.setBounds(100, 90, 250, 30);

        JTextField name = new JTextField("Name: ");
        name.setBackground(Color.WHITE);
        name.setForeground(new Color(0, 0, 0));
        name.setFont(inputFont);
        name.setBounds(10, 180, 150, 30);
        name.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                name.setText("Name: ");
            }

            @Override
            public void focusLost(FocusEvent e) {

            }
        });

        JTextField billing = new JTextField("Billing Address: ");
        billing.setBackground(Color.WHITE);
        billing.setForeground(new Color(0, 0, 0));
        billing.setFont(inputFont);
        billing.setBounds(10, 230, 150, 60);
        billing.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                billing.setText("Billing Address: ");
            }

            @Override
            public void focusLost(FocusEvent e) {

            }
        });

        JTextField zip = new JTextField("Zip Code: ");
        zip.setBackground(Color.WHITE);
        zip.setForeground(new Color(0, 0, 0));
        zip.setFont(inputFont);
        zip.setBounds(10, 320, 150, 30);
        zip.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                zip.setText("Zip Code: ");
            }

            @Override
            public void focusLost(FocusEvent e) {

            }
        });

        JTextField cardnum = new JTextField("Card Number: ");
        cardnum.setBackground(Color.WHITE);
        cardnum.setForeground(new Color(0, 0, 0));
        cardnum.setFont(inputFont);
        cardnum.setBounds(10, 420, 150, 30);
        cardnum.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                cardnum.setText("Card Number: ");
            }

            @Override
            public void focusLost(FocusEvent e) {

            }
        });

        JTextField expiration = new JTextField("Expiration Date: ");
        expiration.setBackground(Color.WHITE);
        expiration.setForeground(new Color(0, 0, 0));
        expiration.setFont(inputFont);
        expiration.setBounds(10, 470, 150, 30);
        expiration.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                expiration.setText("Expiration Date: ");
            }

            @Override
            public void focusLost(FocusEvent e) {

            }
        });

        JTextField cvv = new JTextField("CVV: ");
        cvv.setBackground(Color.WHITE);
        cvv.setForeground(new Color(0, 0, 0));
        cvv.setFont(inputFont);
        cvv.setBounds(10, 520, 150, 30);
        cvv.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                cvv.setText("CVV: ");
            }

            @Override
            public void focusLost(FocusEvent e) {

            }
        });

        JButton addPayment = new JButton("Save Payment");
        addPayment.setBackground(Color.BLUE);
        addPayment.setForeground(Color.WHITE);
        addPayment.setFont(inputFont);
        addPayment.setBounds(20, 560, 140, 40);

        JTextArea help = new JTextArea();
        help.setText("Common Help ....");
        help.setFont(inputFont);
        help.setBackground(Color.YELLOW);
        help.setForeground(Color.BLACK);
        help.setBorder(BorderFactory.createMatteBorder(
                1, 5, 1, 1, Color.red));
        help.setOpaque(true);
        help.setBounds(180, 150, 150, 200);

        JTextArea security = new JTextArea();
        security.setText("Common Help ....");
        security.setFont(inputFont);
        security.setBackground(Color.YELLOW);
        security.setForeground(Color.BLACK);
        security.setBorder(BorderFactory.createMatteBorder(
                1, 5, 1, 1, Color.red));
        security.setOpaque(true);
        security.setBounds(180, 400, 150, 200);

        f.add(t2);
        f.add(name);
        f.add(billing);
        f.add(zip);
        f.add(cardnum);
        f.add(expiration);
        f.add(cvv);
        f.add(addPayment);
        f.add(help);
        f.add(security);
        f.setLayout(null);
        f.setVisible(true);

    }

    public static void Shipping() {
        f.setVisible(false);
        defaultScreen();

        JLabel t2 = new JLabel("Shipping Info");
        t2.setForeground(Color.BLUE);
        t2.setFont(headingFont);
        t2.setBounds(100, 90, 250, 30);

        JTextField name = new JTextField("Name: ");
        name.setBackground(Color.WHITE);
        name.setForeground(new Color(0, 0, 0));
        name.setFont(inputFont);
        name.setBounds(10, 180, 150, 30);
        name.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                name.setText("Name: ");
            }

            @Override
            public void focusLost(FocusEvent e) {

            }
        });

        JTextField billing = new JTextField("Country: ");
        billing.setBackground(Color.WHITE);
        billing.setForeground(new Color(0, 0, 0));
        billing.setFont(inputFont);
        billing.setBounds(10, 230, 150, 30);
        billing.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                billing.setText("Billing Address: ");
            }

            @Override
            public void focusLost(FocusEvent e) {

            }
        });

        JTextField zip = new JTextField("State: ");
        zip.setBackground(Color.WHITE);
        zip.setForeground(new Color(0, 0, 0));
        zip.setFont(inputFont);
        zip.setBounds(10, 280, 150, 30);
        zip.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                zip.setText("Zip Code: ");
            }

            @Override
            public void focusLost(FocusEvent e) {

            }
        });

        JTextField cardnum = new JTextField("Street Address: ");
        cardnum.setBackground(Color.WHITE);
        cardnum.setForeground(new Color(0, 0, 0));
        cardnum.setFont(inputFont);
        cardnum.setBounds(10, 330, 300, 60);
        cardnum.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                cardnum.setText("Card Number: ");
            }

            @Override
            public void focusLost(FocusEvent e) {

            }
        });

        JTextField expiration = new JTextField("Apartment / Suite (Optional): ");
        expiration.setBackground(Color.WHITE);
        expiration.setForeground(new Color(0, 0, 0));
        expiration.setFont(inputFont);
        expiration.setBounds(10, 410, 300, 60);
        expiration.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                expiration.setText("Expiration Date: ");
            }

            @Override
            public void focusLost(FocusEvent e) {

            }
        });

        JTextField cvv = new JTextField("Additional Delivery Requirements: ");
        cvv.setBackground(Color.WHITE);
        cvv.setForeground(new Color(0, 0, 0));
        cvv.setFont(inputFont);
        cvv.setBounds(10, 490, 300, 60);
        cvv.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                cvv.setText("CVV: ");
            }

            @Override
            public void focusLost(FocusEvent e) {

            }
        });

        JButton addPayment = new JButton("Save Shipping");
        addPayment.setBackground(Color.BLUE);
        addPayment.setForeground(Color.WHITE);
        addPayment.setFont(inputFont);
        addPayment.setBounds(20, 560, 140, 40);

        JTextArea help = new JTextArea();
        help.setText("Common Help ....");
        help.setFont(inputFont);
        help.setBackground(Color.YELLOW);
        help.setForeground(Color.BLACK);
        help.setBorder(BorderFactory.createMatteBorder(
                1, 5, 1, 1, Color.red));
        help.setOpaque(true);
        help.setBounds(180, 150, 150, 150);


        f.add(t2);
        f.add(name);
        f.add(billing);
        f.add(zip);
        f.add(cardnum);
        f.add(expiration);
        f.add(cvv);
        f.add(addPayment);
        f.add(help);
        f.setLayout(null);
        f.setVisible(true);
    }

    public static void ModifyAcc() {
        f.setVisible(false);
        defaultScreen();

        JLabel t2 = new JLabel("Modify Account");
        t2.setForeground(Color.BLUE);
        t2.setFont(headingFont);
        t2.setBounds(100, 90, 250, 30);

        JTextField name = new JTextField("Name: ");
        name.setBackground(Color.WHITE);
        name.setForeground(new Color(0, 0, 0));
        name.setFont(inputFont);
        name.setBounds(10, 180, 150, 30);
        name.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                name.setText("Name: ");
            }

            @Override
            public void focusLost(FocusEvent e) {

            }
        });

        JTextField email = new JTextField("Email: ");
        email.setBackground(Color.WHITE);
        email.setForeground(new Color(0, 0, 0));
        email.setFont(inputFont);
        email.setBounds(10, 230, 150, 30);
        email.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                email.setText("Email: ");
            }

            @Override
            public void focusLost(FocusEvent e) {

            }
        });

        JTextField Phone = new JTextField("Phone: ");
        Phone.setBackground(Color.WHITE);
        Phone.setForeground(new Color(0, 0, 0));
        Phone.setFont(inputFont);
        Phone.setBounds(10, 230, 150, 30);
        Phone.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                Phone.setText("Phone: ");
            }

            @Override
            public void focusLost(FocusEvent e) {

            }
        });

        JTextField shippingAdd = new JTextField("Shipping Address: ");
        shippingAdd.setBackground(Color.WHITE);
        shippingAdd.setForeground(new Color(0, 0, 0));
        shippingAdd.setFont(inputFont);
        shippingAdd.setBounds(10, 280, 300, 60);
        shippingAdd.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                shippingAdd.setText("Shipping Address: ");
            }

            @Override
            public void focusLost(FocusEvent e) {

            }
        });

        JTextField billingAdd = new JTextField("Billing Address: ");
        billingAdd.setBackground(Color.WHITE);
        billingAdd.setForeground(new Color(0, 0, 0));
        billingAdd.setFont(inputFont);
        billingAdd.setBounds(10, 280, 300, 60);
        billingAdd.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                billingAdd.setText("Billing Address: ");
            }

            @Override
            public void focusLost(FocusEvent e) {

            }
        });

        JButton accInfo = new JButton("Save Changes");
        accInfo.setBackground(Color.BLUE);
        accInfo.setForeground(Color.WHITE);
        accInfo.setFont(inputFont);
        accInfo.setBounds(20, 560, 140, 40);

        f.add(t2);
        f.add(name);
        f.add(email);
        f.add(Phone);
        f.add(shippingAdd);
        f.add(billingAdd);
        f.add(accInfo);
        f.setLayout(null);
        f.setVisible(true);


    }

    public static void Cart() {
        f.setVisible(false);
        defaultScreen();

        JLabel t2 = new JLabel("Modify Account");
        t2.setForeground(Color.BLUE);
        t2.setFont(headingFont);
        t2.setBounds(100, 90, 250, 30);
    }

    public static void OrderConfirmed() {
        f.setVisible(false);
        defaultScreen();
    }

    public static void ProductDetails(String imageName, String item, String sellerInfo, double price) {
        f.setVisible(false);
        defaultScreen();

        JLabel popular1 = new JLabel();
        popular1.setIcon(new ImageIcon(((new ImageIcon(
                imageName).getImage()
                .getScaledInstance(250, 230,
                        java.awt.Image.SCALE_SMOOTH)))));
        popular1.setBounds(50, 150, 250, 230);

        JLabel t2 = new JLabel(item + "     $" + price);
        t2.setForeground(Color.BLUE);
        t2.setFont(inputFont);
        t2.setBounds(30, 400, 500, 30);

        JButton cartAdd = new JButton("View User Profile");
        cartAdd.setBackground(Color.BLUE);
        cartAdd.setForeground(Color.WHITE);
        cartAdd.setFont(inputFont);
        cartAdd.setBounds(20, 545, 170, 25);
        cartAdd.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == 1) { // 1-left, 2-middle, 3-right button
                    sellerProfile(sellerID);
                }
            }
        });

        JTextArea itemInfo = new JTextArea();
        itemInfo.setText("Details about item \n\nAbout the Owner\n" + sellerInfo);
        itemInfo.setFont(inputFont);
        itemInfo.setBackground(Color.YELLOW);
        itemInfo.setForeground(Color.BLACK);
        itemInfo.setBorder(BorderFactory.createMatteBorder(
                1, 5, 1, 1, Color.red));
        itemInfo.setOpaque(true);
        itemInfo.setBounds(20, 430, 300, 110);

        JButton viewPro = new JButton("Add to Cart");
        viewPro.setBackground(Color.BLUE);
        viewPro.setForeground(Color.WHITE);
        viewPro.setFont(inputFont);
        viewPro.setBounds(200, 400, 130, 25);

        f.add(popular1);
        f.add(t2);
        f.add(cartAdd);
        f.add(itemInfo);
        f.add(viewPro);
        f.setLayout(null);
        f.setVisible(true);

    }

    public static void sellerProfile(int sellerID) {
        f.setVisible(false);
        defaultScreen();

        String sellerInfo = "";
        if (sellerID == 1) {
            sellerInfo = seller1;
        } else if (sellerID == 2) {
            sellerInfo = seller2;
        } else if (sellerID == 3) {
            sellerInfo = seller3;
        } else if (sellerID == 4) {
            sellerInfo = seller4;
        }

        JTextArea mission = new JTextArea();
        mission.setText("Info about seller.........\n\n" + sellerInfo);
        mission.setFont(inputFont);
        mission.setBackground(Color.YELLOW);
        mission.setForeground(Color.BLACK);
        mission.setBorder(BorderFactory.createMatteBorder(
                1, 5, 1, 1, Color.red));
        mission.setOpaque(true);
        mission.setBounds(30, 150, 250, 350);

        f.add(mission);
        f.setLayout(null);
        f.setVisible(true);
    }

    public static void AboutScreen() {
        f.setVisible(false);
        defaultScreen();

        String about = "ModX Royal is a platform where users can buy and sell different antiquities. ModX Royal makes helps connect buyers with people who want to sell the kind of product they’re interested in.\n" +
                "It also helps sellers being  able to make products available to buyers that are not available through the general public marketplace.\n" +
                "Make verified sellers available to the customers who sell authentic products.\n" +
                "Provide a secure and trustworthy platform for the user population to conduct and take part in auctions.";

        JTextArea mission = new JTextArea();
        mission.setText(about);
        mission.setFont(smallFont);
        mission.setBackground(Color.YELLOW);
        mission.setForeground(Color.BLACK);
        mission.setLineWrap(true);
        mission.setWrapStyleWord(true);
        mission.setBorder(BorderFactory.createMatteBorder(
                1, 5, 1, 1, Color.red));
        mission.setOpaque(true);
        mission.setBounds(10, 150, 250, 350);

        f.add(mission);
        f.setLayout(null);
        f.setVisible(true);

    }

    public static void TermsConditions() {
        f.setVisible(false);
        defaultScreen();
        String terms = "Preview your Terms & Conditions\n" +
                "Terms and Conditions\n" +
                "Welcome to ModX Royal!\n" +
                "\n" +
                "These terms and conditions outline the rules and regulations for the use of Modx Royal's Website, located at Www.modXRoyal.com.\n" +
                "\n" +
                "By accessing this website we assume you accept these terms and conditions. Do not continue to use ModX Royal if you do not agree to take all of the terms and conditions stated on this page.\n" +
                "\n" +
                "The following terminology applies to these Terms and Conditions, Privacy Statement and Disclaimer Notice and all Agreements: \"Client\", \"You\" and \"Your\" refers to you, the person log on this website and compliant to the Company’s terms and conditions. \"The Company\", \"Ourselves\", \"We\", \"Our\" and \"Us\", refers to our Company. \"Party\", \"Parties\", or \"Us\", refers to both the Client and ourselves. All terms refer to the offer, acceptance and consideration of payment necessary to undertake the process of our assistance to the Client in the most appropriate manner for the express purpose of meeting the Client’s needs in respect of provision of the Company’s stated services, in accordance with and subject to, prevailing law of Netherlands. Any use of the above terminology or other words in the singular, plural, capitalization and/or he/she or they, are taken as interchangeable and therefore as referring to same.\n" +
                "\n" +
                "Cookies\n" +
                "We employ the use of cookies. By accessing ModX Royal, you agreed to use cookies in agreement with the Modx Royal's Privacy Policy.\n" +
                "\n" +
                "Most interactive websites use cookies to let us retrieve the user’s details for each visit. Cookies are used by our website to enable the functionality of certain areas to make it easier for people visiting our website. Some of our affiliate/advertising partners may also use cookies.\n" +
                "\n" +
                "License\n" +
                "Unless otherwise stated, Modx Royal and/or its licensors own the intellectual property rights for all material on ModX Royal. All intellectual property rights are reserved. You may access this from ModX Royal for your own personal use subjected to restrictions set in these terms and conditions.\n" +
                "\n" +
                "You must not:\n" +
                "\n" +
                "Republish material from ModX Royal\n" +
                "Sell, rent or sub-license material from ModX Royal\n" +
                "Reproduce, duplicate or copy material from ModX Royal\n" +
                "Redistribute content from ModX Royal";

        JTextArea tc = new JTextArea();
        tc.setText(terms);
        tc.setFont(smallFont);
        tc.setBackground(Color.YELLOW);
        tc.setForeground(Color.BLACK);
        tc.setLineWrap(true);
        tc.setWrapStyleWord(true);
        tc.setBorder(BorderFactory.createMatteBorder(
                1, 5, 1, 1, Color.red));
        tc.setOpaque(true);
        tc.setBounds(10, 150, 550, 350);

        f.setSize(600, 700);
        f.add(tc);
        f.setLayout(null);
        f.setVisible(true);

    }

    public static void PoliciesScreen() {
        f.setVisible(false);
        defaultScreen();

        String policy = "Privacy Policy for Modx Royal\n" +
                "At ModX Royal, accessible from Www.modXRoyal.com, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by ModX Royal and how we use it.\n" +
                "\n" +
                "If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.\n" +
                "\n" +
                "This Privacy Policy applies only to our online activities and is valid for visitors to our website with regards to the information that they shared and/or collect in ModX Royal. This policy is not applicable to any information collected offline or via channels other than this website. Our Privacy Policy was created with the help of the Free Privacy Policy Generator.\n" +
                "\n" +
                "Consent\n" +
                "By using our website, you hereby consent to our Privacy Policy and agree to its terms.\n" +
                "\n" +
                "Information we collect\n" +
                "The personal information that you are asked to provide, and the reasons why you are asked to provide it, will be made clear to you at the point we ask you to provide your personal information.\n" +
                "\n" +
                "If you contact us directly, we may receive additional information about you such as your name, email address, phone number, the contents of the message and/or attachments you may send us, and any other information you may choose to provide.\n" +
                "\n" +
                "When you register for an Account, we may ask for your contact information, including items such as name, company name, address, email address, and telephone number.\n" +
                "\n" +
                "How we use your information\n" +
                "We use the information we collect in various ways, including to:\n" +
                "\n" +
                "Provide, operate, and maintain our website\n" +
                "Improve, personalize, and expand our website\n" +
                "Understand and analyze how you use our website\n" +
                "Develop new products, services, features, and functionality\n" +
                "Communicate with you, either directly or through one of our partners, including for customer service, to provide you with updates and other information relating to the website, and for marketing and promotional purposes\n" +
                "Send you emails\n" +
                "Find and prevent fraud\n" +
                "Log Files\n" +
                "ModX Royal follows a standard procedure of using log files. These files log visitors when they visit websites. All hosting companies do this and a part of hosting services' analytics.";

        JTextArea policies = new JTextArea();
        policies.setText(policy);
        policies.setFont(smallFont);
        policies.setBackground(Color.YELLOW);
        policies.setForeground(Color.BLACK);
        policies.setBorder(BorderFactory.createMatteBorder(
                1, 5, 1, 1, Color.red));
        policies.setOpaque(true);
       policies.setLineWrap(true);
        policies.setWrapStyleWord(true);
        policies.setBounds(10, 150, 550, 500);

        JScrollPane scrollPane = new JScrollPane(policies);

        f.setSize(600, 700);
        f.add(scrollPane);
        f.add(policies);
        f.setLayout(null);
        f.setVisible(true);

    }

    public static void FAQScreen() {
        f.setVisible(false);
        defaultScreen();

        JTextArea faq = new JTextArea();
        faq.setText("Common FAQs here.....");
        faq.setFont(inputFont);
        faq.setBackground(Color.YELLOW);
        faq.setForeground(Color.BLACK);
        faq.setBorder(BorderFactory.createMatteBorder(
                1, 5, 1, 1, Color.red));
        faq.setOpaque(true);
        faq.setBounds(30, 150, 250, 350);

        f.add(faq);
        f.setLayout(null);
        f.setVisible(true);

    }

    public static void SellerVerification() {
        f.setVisible(false);
        defaultScreen();

        JTextArea sv = new JTextArea();
        sv.setText("Seller Verification Info here.....");
        sv.setFont(inputFont);
        sv.setBackground(Color.YELLOW);
        sv.setForeground(Color.BLACK);
        sv.setBorder(BorderFactory.createMatteBorder(
                1, 5, 1, 1, Color.red));
        sv.setOpaque(true);
        sv.setBounds(30, 150, 250, 350);

        f.add(sv);
        f.setLayout(null);
        f.setVisible(true);

    }

    public static void Help() {
        f.setVisible(false);
        defaultScreen();

        JTextArea help = new JTextArea();
        help.setText("Help Info here.....");
        help.setFont(inputFont);
        help.setBackground(Color.YELLOW);
        help.setForeground(Color.BLACK);
        help.setBorder(BorderFactory.createMatteBorder(
                1, 5, 1, 1, Color.red));
        help.setOpaque(true);
        help.setBounds(30, 150, 250, 350);

        f.add(help);
        f.setLayout(null);
        f.setVisible(true);

    }

    public static void main(String[] args) throws IOException {
        WelcomeScreen();
    }

}
